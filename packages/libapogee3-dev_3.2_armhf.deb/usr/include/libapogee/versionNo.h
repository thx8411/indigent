#if !defined(VERSION_NUM_H___)
#define VERSION_NUM_H___

// for windows
#define FILEVER        3,0,38,3234
#define PRODUCTVER     3,0,38,3234
#define STRFILEVER     "3, 0, 38, 3234\0"
#define STRPRODUCTVER  "3, 0, 38, 3234\0"

// for linux
#define APOGEE_MAJOR_VERSION 3
#define APOGEE_MINOR_VERSION 0
#define APOGEE_PATCH_VERSION 3234

#endif
