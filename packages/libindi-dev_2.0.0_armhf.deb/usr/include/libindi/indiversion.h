/* Set INDI Library version */
#define INDI_VERSION 2.0.0

/* Define INDI Data Dir */
#define DATA_INSTALL_DIR "/usr/share/indi/"
